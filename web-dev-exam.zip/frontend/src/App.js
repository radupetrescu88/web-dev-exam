import { React, useEffect } from "react";
import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import logo from "./logo.svg";

import { Routes, Route, Navigate } from "react-router-dom";

import ShipsPage from "./components/ships.component";

import "bootstrap/dist/css/bootstrap.min.css";
import "react-bootstrap-table-next/dist/react-bootstrap-table2.min.css";
import "react-bootstrap-table2-paginator/dist/react-bootstrap-table2-paginator.min.css";
import "react-bootstrap-table2-filter/dist/react-bootstrap-table2-filter.min.css";
import ShipPage from "./components/shipPage.component";
import CrewMemberPage from "./components/crewMemberPage.component";

const App = () => {
  const navigate = useNavigate();
  const { pathname } = window.location;
  useEffect(() => {
    if (pathname === "/") {
      navigate("/ships");
    }
  });
  return (
    <div className="app">
      <Routes>
        <Route
          path="/ships/:shipId/crew-members/create"
          element={<CrewMemberPage create={true} />}
        />
        <Route
          path="/ships/:shipId/crew-members/:crewMemberId"
          element={<CrewMemberPage create={false} />}
        />
        <Route path="/ships/create" element={<ShipPage create={true} />} />
        <Route path="/ships/:shipId" element={<ShipPage create={false} />} />
        <Route path="/ships" element={<ShipsPage />} />
      </Routes>
    </div>
  );
};

export default App;
