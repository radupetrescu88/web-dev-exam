import React, { useEffect, useState } from "react";

import {
  Routes,
  Route,
  Navigate,
  useNavigate,
  useParams,
} from "react-router-dom";
import Navbar from "react-bootstrap/Navbar";
import Container from "react-bootstrap/Container";
import Nav from "react-bootstrap/Nav";
import NavDropdown from "react-bootstrap/NavDropdown";
import paginationFactory from "react-bootstrap-table2-paginator";
import filterFactory, { textFilter } from "react-bootstrap-table2-filter";

import BootstrapTable from "react-bootstrap-table-next";

import Button from "react-bootstrap/Button";
import Card from "react-bootstrap/Card";

import { useDispatch, useSelector } from "react-redux";
import { getShips } from "../reducers/ships";
import { retrieveShips, createShip, updateShip } from "../actions/ships";
import { retrieveCrewMembers, deleteCrewMember } from "../actions/crewMembers";
import { getCrewMembers } from "../reducers/crewMembers";

import "./shipPage.css";

const ShipPage = ({ create = true }) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const params = useParams();
  const ships = useSelector(getShips);
  let ship = {};

  const crewMembers = useSelector(getCrewMembers);

  const [name, setName] = useState("");
  const [displacement, setDisplacement] = useState("");
  const [nameError, setNameError] = useState("");
  const [displacementError, setDisplacementError] = useState("");

  useEffect(() => {
    if (create === false && params.shipId) {
      ship = ships.find((item) => item.id === parseInt(params.shipId));
      setName(ship?.name || "");
      setDisplacement(ship?.displacement || "");
      // get ship by id
    }
  }, []);

  useEffect(() => {
    dispatch(retrieveShips());
    if (!create && params?.shipId) {
      dispatch(retrieveCrewMembers(params?.shipId));
    }
  }, []);

  const formValidation = () => {
    let formIsValid = true;

    if (name.length == 0) {
      formIsValid = false;
      setNameError("Name not valid");
    } else {
      setNameError("");
      formIsValid = true;
    }
    if (isNaN(displacement) || parseInt(displacement) <= 50) {
      formIsValid = false;
      setDisplacementError(
        "Displacement not valid. Must be a number greater than 50"
      );
    } else {
      setDisplacementError("");
      formIsValid = true;
    }

    return formIsValid;
  };

  const onSubmit = (e) => {
    e.preventDefault();
    const formIsValid = formValidation();

    if (formIsValid === true) {
      if (create) {
        dispatch(createShip({ name, displacement: parseInt(displacement) }))
          .then(() => {
            navigate("/ships");
          })
          .catch(() => {});
      } else if (params?.shipId) {
        dispatch(
          updateShip(params?.shipId, {
            name,
            displacement: parseInt(displacement),
          })
        )
          .then(() => {
            navigate("/ships");
          })
          .catch(() => {});
      }
    }
  };

  const deleteButton = (cell, row, rowIndex, formatExtraData) => {
    return (
      <Button
        onClick={() => {
          dispatch(deleteCrewMember(row?.id))
            .then(() => {
              navigate(`/ships/${params?.shipId}`);
            })
            .catch(() => {});
        }}
      >
        Delete
      </Button>
    );
  };

  const idButton = (cell, row, rowIndex, formatExtraData) => {
    return (
      <Button
        onClick={() => {
          navigate(`/ships/${params?.shipId}/crew-members/${row.id}`);
        }}
      >
        {row.id}
      </Button>
    );
  };

  const columns = [
    {
      dataField: "id",
      text: "ID",
      formatter: idButton,
      filter: textFilter(),
    },
    {
      dataField: "name",
      text: "Crew member name",
      sort: true,
      filter: textFilter(),
    },
    {
      dataField: "role",
      text: "Crew member role",
      sort: true,
      filter: textFilter(),
    },
    {
      dataField: "action",
      text: "Action",
      formatter: deleteButton,
    },
  ];

  const handleAddCrewMemberPage = () => {
    navigate(`/ships/${params?.shipId}/crew-members/create`);
  };

  return (
    <div className="login-page d-flex justify-content-center">
      <Card className="col-md-6">
        <Card.Title className="card-title d-flex justify-content-center">
          {create ? "Create ship page" : "Edit ship page"}
        </Card.Title>
        <Card.Body>
          <div className="App">
            <div className="container">
              <div className="row d-flex justify-content-center">
                <form id="loginform" onSubmit={onSubmit}>
                  <div className="form-group">
                    <label>Name</label>
                    <input
                      className="form-control"
                      id="name"
                      name="name"
                      placeholder="Enter name"
                      defaultValue={name}
                      onChange={(event) => setName(event.target.value)}
                    />
                    <small id="nameHelp" className="text-danger form-text">
                      {nameError}
                    </small>
                  </div>
                  <div className="form-group">
                    <label>Displacement</label>
                    <input
                      className="form-control"
                      id="displacement"
                      name="displacement"
                      placeholder="Enter displacement"
                      defaultValue={displacement}
                      onChange={(event) => setDisplacement(event.target.value)}
                    />
                    <small id="nameHelp" className="text-danger form-text">
                      {displacementError}
                    </small>
                  </div>
                  {!create && (
                    <div className="crew-table">
                      <BootstrapTable
                        hover={true}
                        keyField="id"
                        data={crewMembers}
                        columns={columns}
                        pagination={paginationFactory()}
                        filter={filterFactory()}
                      />
                      <Button
                        className="crew-member-button"
                        onClick={() => handleAddCrewMemberPage()}
                      >
                        Add crew member
                      </Button>
                    </div>
                  )}

                  <div className="buttons">
                    <Button
                      className="login-button"
                      type="submit"
                      variant="primary"
                    >
                      {create ? "Create ship" : "Edit ship"}
                    </Button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </Card.Body>
      </Card>
    </div>
  );
};

export default ShipPage;
