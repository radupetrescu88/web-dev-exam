import React, { useEffect } from "react";

import { useNavigate } from "react-router-dom";

import BootstrapTable from "react-bootstrap-table-next";
import paginationFactory from "react-bootstrap-table2-paginator";
import filterFactory, { textFilter } from "react-bootstrap-table2-filter";

import Button from "react-bootstrap/Button";

import { useDispatch, useSelector } from "react-redux";
import { getShips } from "../reducers/ships";
import { retrieveShips, deleteShip } from "../actions/ships";

import "./ships.css";

const ShipsPage = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const ships = useSelector(getShips);

  useEffect(() => {
    dispatch(retrieveShips());
  }, []);

  const deleteButton = (cell, row, rowIndex, formatExtraData) => {
    return (
      <Button
        onClick={() => {
          dispatch(deleteShip(row?.id))
            .then(() => {
              navigate("/ships");
            })
            .catch(() => {});
        }}
      >
        Delete
      </Button>
    );
  };

  const idButton = (cell, row, rowIndex, formatExtraData) => {
    return (
      <Button
        onClick={() => {
          navigate(`/ships/${row.id}`);
        }}
      >
        {row.id}
      </Button>
    );
  };

  const columns = [
    {
      dataField: "id",
      text: "ID",
      formatter: idButton,
      filter: textFilter(),
    },
    {
      dataField: "name",
      text: "Ship name",
      sort: true,
      filter: textFilter(),
    },
    {
      dataField: "displacement",
      text: "Ship displacement",
      sort: true,
      filter: textFilter(),
    },
    {
      dataField: "action",
      text: "Action",
      formatter: deleteButton,
    },
  ];

  const handleAddShipPage = () => {
    navigate("/ships/create");
  };

  return (
    <div className="container">
      <div className="row">
        <div className="col-sm 12">
          <BootstrapTable
            hover={true}
            keyField="id"
            data={ships}
            columns={columns}
            pagination={paginationFactory()}
            filter={filterFactory()}
          />
          <Button onClick={() => handleAddShipPage()}>Add ship</Button>
        </div>
        <div className="import-export">
          <Button
            className="import-button"
            onClick={() => {
              // implement import
            }}
          >
            Import
          </Button>
          <Button
            onClick={() => {
              // implement export
            }}
          >
            Export
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ShipsPage;
