import React, { useEffect, useState } from "react";

import { useNavigate, useParams } from "react-router-dom";

import Button from "react-bootstrap/Button";
import Card from "react-bootstrap/Card";

import { useDispatch, useSelector } from "react-redux";
import { retrieveCrewMembers, createCrewMember } from "../actions/crewMembers";
import { getCrewMembers } from "../reducers/crewMembers";

import "./shipPage.css";

const CrewMemberPage = ({ create = true }) => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const params = useParams();
  let crewMember = {};

  const crewMembers = useSelector(getCrewMembers);
  const roles = ["CAPTAIN", "BOATSWAIN"];

  const [name, setName] = useState("");
  const [role, setRole] = useState("");
  const [nameError, setNameError] = useState("");
  const [roleError, setRoleError] = useState("");

  useEffect(() => {
    if (create === false && params.crewMemberId) {
      crewMember = crewMembers.find(
        (item) => item.id === parseInt(params.crewMemberId)
      );
      setName(crewMember?.name || "");
      setRole(crewMember?.role || "");
    }
  }, []);

  useEffect(() => {
    if (!create && params?.shipId) {
      dispatch(retrieveCrewMembers(params?.shipId));
    }
  }, []);

  const formValidation = () => {
    let formIsValid = true;

    if (name.length == 0) {
      formIsValid = false;
      setNameError("Name not valid");
    } else {
      setNameError("");
      formIsValid = true;
    }

    if (role === "") {
      formIsValid = false;
      setRoleError("You must select a role!");
    } else {
      setRoleError("");
      formIsValid = true;
    }

    return formIsValid;
  };

  const onSubmit = (e) => {
    e.preventDefault();
    const formIsValid = formValidation();

    if (formIsValid === true) {
      if (create) {
        dispatch(createCrewMember({ name, role, shipId: params?.shipId }))
          .then(() => {
            navigate(`/ships/${params?.shipId}`);
          })
          .catch(() => {});
      } else if (params?.crewMemberId) {
        navigate(`/ships/${params?.shipId}`);
      }
    }
  };

  return (
    <div className="login-page d-flex justify-content-center">
      <Card className="col-md-6">
        <Card.Title className="card-title d-flex justify-content-center">
          {create ? "Create crew member" : "Edit crew member"}
        </Card.Title>
        <Card.Body>
          <div className="App">
            <div className="container">
              <div className="row d-flex justify-content-center">
                <form id="loginform" onSubmit={onSubmit}>
                  <div className="form-group">
                    <label>Name</label>
                    <input
                      className="form-control"
                      id="name"
                      name="name"
                      placeholder="Enter name"
                      defaultValue={name}
                      onChange={(event) => setName(event.target.value)}
                    />
                    <small id="nameHelp" className="text-danger form-text">
                      {nameError}
                    </small>
                  </div>

                  <div className="form-group">
                    <label>Role</label>
                    <select onChange={(event) => setRole(event.target.value)}>
                      {role === "" && <option>{"Select a role"}</option>}
                      {roles.map((role) => (
                        <option key={role.length} value={role}>
                          {role}
                        </option>
                      ))}
                    </select>
                    <small id="rolehelp" className="text-danger form-text">
                      {roleError}
                    </small>
                  </div>
                  <div className="buttons">
                    <Button
                      className="login-button"
                      type="submit"
                      variant="primary"
                    >
                      {create ? "Create crew member" : "Edit crew member"}
                    </Button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </Card.Body>
      </Card>
    </div>
  );
};

export default CrewMemberPage;
