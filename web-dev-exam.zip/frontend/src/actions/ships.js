import { CREATE_SHIP, RETRIEVE_SHIPS, UPDATE_SHIP, DELETE_SHIP } from "./types";

import ShipService from "../services/ship.service";

export const createShip = (data) => async (dispatch) => {
  console.log("data", data);
  try {
    const res = await ShipService.create(data);

    dispatch({
      type: CREATE_SHIP,
      payload: res.data,
    });

    return Promise.resolve(res.data);
  } catch (err) {
    return Promise.reject(err);
  }
};

export const updateShip = (id, data) => async (dispatch) => {
  try {
    const res = await ShipService.update(id, data);

    dispatch({
      type: UPDATE_SHIP,
      payload: { ...data, id },
    });

    return Promise.resolve(res.data);
  } catch (err) {
    return Promise.reject(err);
  }
};

export const retrieveShips = () => async (dispatch) => {
  try {
    const res = await ShipService.getAll();

    dispatch({
      type: RETRIEVE_SHIPS,
      payload: res.data,
    });
  } catch (err) {
    console.log(err);
  }
};

export const deleteShip = (id) => async (dispatch) => {
  try {
    const res = await ShipService.deleteShip(id);

    dispatch({
      type: DELETE_SHIP,
      payload: { id },
    });

    return Promise.resolve(res.data);
  } catch (err) {
    return Promise.reject(err);
  }
};
