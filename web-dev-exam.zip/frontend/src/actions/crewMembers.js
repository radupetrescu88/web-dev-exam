import {
  CREATE_CREW_MEMBER,
  RETRIEVE_CREW_MEMBERS,
  UPDATE_CREW_MEMBER,
  DELETE_CREW_MEMBER,
} from "./types";

import CrewMemberService from "../services/crewMember.service";

export const createCrewMember = (data) => async (dispatch) => {
  try {
    const res = await CrewMemberService.create(data);

    dispatch({
      type: CREATE_CREW_MEMBER,
      payload: res.data,
    });

    return Promise.resolve(res.data);
  } catch (err) {
    return Promise.reject(err);
  }
};

export const updateCrewMember = (id, data) => async (dispatch) => {
  try {
    const res = await CrewMemberService.update(id, data);

    dispatch({
      type: UPDATE_CREW_MEMBER,
      payload: { ...data, id },
    });

    return Promise.resolve(res.data);
  } catch (err) {
    return Promise.reject(err);
  }
};

export const retrieveCrewMembers = (shipId) => async (dispatch) => {
  try {
    const res = await CrewMemberService.getAll(shipId);

    dispatch({
      type: RETRIEVE_CREW_MEMBERS,
      payload: res.data,
    });
  } catch (err) {
    console.log(err);
  }
};

export const deleteCrewMember = (id) => async (dispatch) => {
  try {
    const res = await CrewMemberService.deleteCrewMember(id);

    dispatch({
      type: DELETE_CREW_MEMBER,
      payload: { id },
    });

    return Promise.resolve(res.data);
  } catch (err) {
    return Promise.reject(err);
  }
};
