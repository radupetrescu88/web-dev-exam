import {
  CREATE_CREW_MEMBER,
  RETRIEVE_CREW_MEMBERS,
  UPDATE_CREW_MEMBER,
  DELETE_CREW_MEMBER,
} from "../actions/types";

const initialState = [];

export default function projectsReducer(crewMembers = initialState, action) {
  const { type, payload } = action;

  switch (type) {
    case CREATE_CREW_MEMBER:
      return [...crewMembers, payload];

    case UPDATE_CREW_MEMBER:
      return crewMembers.map((crewMember) => {
        if (crewMember.id === payload.id) {
          return {
            ...crewMember,
            ...payload,
          };
        } else {
          return crewMember;
        }
      });

    case RETRIEVE_CREW_MEMBERS:
      return payload;

    case DELETE_CREW_MEMBER:
      return crewMembers.filter((crewMember) => crewMember.id !== payload.id);

    default:
      return crewMembers;
  }
}

export const getCrewMembers = (state) => state.crewMembers;
