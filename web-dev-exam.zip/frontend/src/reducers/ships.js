import {
  CREATE_SHIP,
  RETRIEVE_SHIPS,
  UPDATE_SHIP,
  DELETE_SHIP,
} from "../actions/types";

const initialState = [];

export default function projectsReducer(ships = initialState, action) {
  const { type, payload } = action;

  switch (type) {
    case CREATE_SHIP:
      return [...ships, payload];

    case UPDATE_SHIP:
      return ships.map((ship) => {
        if (ship.id === payload.id) {
          return {
            ...ship,
            ...payload,
          };
        } else {
          return ship;
        }
      });

    case RETRIEVE_SHIPS:
      return payload;

    case DELETE_SHIP:
      return ships.filter((ship) => ship.id !== payload.id);

    default:
      return ships;
  }
}

export const getShips = (state) => state.ships;
