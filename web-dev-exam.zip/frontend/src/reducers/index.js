import { combineReducers } from "redux";

import ships from "./ships";
import crewMembers from "./crewMembers";

export default combineReducers({
  ships,
  crewMembers,
});
