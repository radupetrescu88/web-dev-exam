module.exports = (sequelize, Sequelize) => {
  const Ship = sequelize.define("ship", {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    name: {
      type: Sequelize.STRING,
      allowNull: false,
      validate: {
        // Min 3 characters:
        hasThreeCharacters(value) {
          if (value.length <= 2) {
            throw new Error("Name should have at least 3 characters");
          }
        },
      },
    },
    displacement: {
      type: Sequelize.STRING,
      allowNull: false,
      validate: {
        min: 51,
      },
    },
  });
  return Ship;
};
