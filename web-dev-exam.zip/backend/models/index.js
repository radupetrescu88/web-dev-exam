const Sequelize = require("sequelize");

const DB_USERNAME = "root";
const DB_PASSWORD = "spike88";
const sequelize = new Sequelize(process.env.DATABASE_URL, {
  dialect: "postgres",
  protocol: "postgres",
  dialectOptions: {
    ssl: {
      require: true,
      rejectUnauthorized: false,
    },
  },
});

const db = {};

db.Sequelize = Sequelize;
db.sequelize = sequelize;

db.ship = require("../models/shipModel.js")(sequelize, Sequelize);
db.crewMember = require("../models/crewMemberModel.js")(sequelize, Sequelize);

// Ship - crew member
db.ship.hasMany(db.crewMember, {
  foreignKey: "crewMemberId",
});
db.crewMember.belongsTo(db.ship);

module.exports = db;
