module.exports = (sequelize, Sequelize) => {
  const CrewMember = sequelize.define("crewmember", {
    id: {
      type: Sequelize.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    name: {
      type: Sequelize.STRING,
      allowNull: false,
      validate: {
        // Min 5 characters:
        hasThreeCharacters(value) {
          if (value.length <= 4) {
            throw new Error("CrewMember should have at least 5 characters");
          }
        },
      },
    },
    role: {
      type: Sequelize.ENUM,
      values: ["CAPTAIN", "BOATSWAIN"],
      defaultValue: "CAPTAIN",
    },
  });
  return CrewMember;
};
