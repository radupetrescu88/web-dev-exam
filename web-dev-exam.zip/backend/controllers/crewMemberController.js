const db = require("../models");
const crewMember = db.crewMember;

// Retrieve all ships from the database.
exports.findAll = (req, res) => {
  const shipId = req.params.shipId;
  crewMember
    .findAll({
      where: {
        shipId: shipId,
      },
    })
    .then((data) => {
      res.send(data);
    })
    .catch((err) => {
      res.status(500).send({
        message:
          err.message || "Some error occurred while retrieving tutorials.",
      });
    });
};

// Create and Save a new Project
exports.create = (req, res) => {
  // Validate request
  if (!req.body.name && !req.body.role && !req.body.shipId) {
    res.status(400).send({
      message: "Name and role cannot be empty!",
    });
    return;
  }

  // Create a project object
  const crewMemberObject = {
    name: req.body.name,
    role: req.body.role,
    shipId: req.body.shipId,
  };

  // Save Project in the database
  crewMember
    .create(crewMemberObject)
    .then((data) => {
      res.send(data);
    })
    .catch((err) => {
      res.status(500).send({
        message: err.message || "Some error occurred while creating the ship.",
      });
    });
};

// Update a Project by the id in the request
exports.update = (req, res) => {
  // Validate request
  if (!req.body.name && !req.body.role) {
    res.status(400).send({
      message: "Name and role cannot be empty!",
    });
    return;
  }

  const id = req.params.id;

  crewMember
    .update(req.body, {
      where: { id: id },
    })
    .then((num) => {
      if (num == 1) {
        res.send({
          message: "Crew member was updated successfully.",
        });
      } else {
        res.send({
          message: `Cannot update Crew Member with id=${id}.`,
        });
      }
    })
    .catch((err) => {
      res.status(500).send({
        message: "Error updating Crew Member with id=" + id,
      });
    });
};

// Delete a User with the specified id in the request
exports.delete = (req, res) => {
  const id = req.params.id;

  crewMember
    .destroy({
      where: { id: id },
    })
    .then((num) => {
      if (num == 1) {
        res.send({
          message: "Crew Member was deleted successfully!",
        });
      } else {
        res.send({
          message: `Cannot delete Crew Member with id=${id}!`,
        });
      }
    })
    .catch((err) => {
      res.status(500).send({
        message: "Could not delete Crew Member with id=" + id,
      });
    });
};
