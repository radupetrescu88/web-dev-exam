const controller = require("../controllers/shipController.js");

module.exports = function (app) {
  app.use(function (req, res, next) {
    res.header(
      "Access-Control-Allow-Headers",
      "x-access-token, Origin, Content-Type, Accept"
    );
    next();
  });

  app.get("/api/ships", [], controller.findAll);
  app.post("/api/ships", [], controller.create);
  app.put("/api/ships/:id", [], controller.update);
  app.delete("/api/ships/:id", [], controller.delete);
};
